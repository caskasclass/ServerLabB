package pkg;

import java.io.Serializable;
import java.util.ArrayList;

import java.sql.*;

/**
 *
 * @author lorenzo
 */
public class Track implements Serializable {

    private String track_id;
    private String name;
    private int duration;
    private String artist_name;
    private String album_name;
    private String album_img0;
    private String album_img1;
    private String album_img2;

    //questo è il costruttore a cui viene già mandato anche l'array delle emozioni più gli altri dati, non so se potà servire
    public Track(String track_id, String name, int duration, String artist_name, String album_name, String album_img0, String album_img1, String album_img2) {
        this.track_id = track_id;
        this.name = name;
        this.duration = duration / (1000 * 60);
        this.artist_name = artist_name;
        this.album_name = album_name;
        this.album_img0 = album_img0;
        this.album_img1 = album_img1;
        this.album_img2 = album_img2;
    }

    public String getTrack_id() {
        return track_id;
    }

    public String getName() {
        return name;
    }

    public int getDuration() {
        return duration;
    }

    public String getArtist_name() {
        return artist_name;
    }

    public String getAlbum_name() {
        return album_name;
    }

    public String getAlbum_img0() {
        return album_img0;
    }

    public String getAlbum_img1() {
        return album_img1;
    }

    public String getAlbum_img2() {
        return album_img2;
    }

    //inserisco comunque il metodo toString anche se non so se potrà servire
    @Override
    public String toString() {
        String res = this.track_id + "<SEP>" + this.name + "<SEP>" + this.getDuration() + "<SEP>" + this.artist_name + "<SEP>"
                + this.album_img0 + "<SEP>" + this.album_img1 + "<SEP>" + this.album_img2 + "<SEP>";
        res += "\n";
        return res;
    }
}
